# SoleCheck Online MVP

Deployable front-end prototype for SoleCheck: shoes, clothes, bags and accessories; search; scan/upload; explainable authenticity UI; history; genuine-shopping UI.

Production still needs: secure backend, AI/OCR, verified product/reference database, user accounts, storage, affiliate network approvals/program IDs, live feeds, monitoring, backups, WAF/rate limiting, and legal pages.

Never put API keys, affiliate secrets, or private credentials in the frontend.
